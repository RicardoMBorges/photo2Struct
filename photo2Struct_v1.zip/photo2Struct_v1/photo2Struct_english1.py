import streamlit as st
import subprocess
import tempfile
import os
from rdkit import Chem
from rdkit.Chem import Draw, Descriptors, rdMolDescriptors, Crippen, Lipinski
from rdkit.Chem import AllChem, rdMolTransforms
import py3Dmol
import pandas as pd

st.set_page_config(layout="wide")
st.title("🧪 photo2Struct – Chemical Structure Recognition")
st.write("Upload an image of a chemical structure to extract the **SMILES**, view the structure, and get molecular descriptors.")

uploaded_file = st.file_uploader("📄 Upload an image (PNG or JPG)", type=["png", "jpg", "jpeg"])

def osra_image_to_smiles(image_bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        tmp.close()
        wsl_path = "/mnt/" + tmp.name[0].lower() + tmp.name[2:].replace('\\', '/').replace('\\\\', '/')
    try:
        result = subprocess.run(["wsl", "osra", wsl_path], capture_output=True, text=True, timeout=15)
        smiles = result.stdout.strip()
        if smiles == "":
            return None, "⚠️ No SMILES recognized."
        return smiles, None
    except Exception as e:
        return None, f"Error running OSRA: {e}"

def mol_from_smiles(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "Invalid SMILES."
    Chem.rdDepictor.Compute2DCoords(mol)
    return mol, None

def generate_3d_model(mol):
    mol3d = Chem.AddHs(mol)
    if AllChem.EmbedMolecule(mol3d) != 0:
        return None
    AllChem.UFFOptimizeMolecule(mol3d)
    return mol3d

def render_3d(mol3d):
    mb = Chem.MolToMolBlock(mol3d)
    viewer = py3Dmol.view(width=400, height=400)
    viewer.addModel(mb, "mol")
    viewer.setStyle({"stick": {}})
    viewer.zoomTo()
    return viewer

def calculate_descriptors(mol):
    try:
        inchi = Chem.MolToInchi(mol)
    except:
        inchi = "Unavailable"

    try:
        inchikey = Chem.MolToInchiKey(mol)
    except:
        inchikey = "Unavailable"

    data = {
        'Molecular Formula': rdMolDescriptors.CalcMolFormula(mol),
        'Exact Mass': round(Descriptors.ExactMolWt(mol), 5),
        'Molecular Weight (g/mol)': round(Descriptors.MolWt(mol), 2),
        'LogP (Crippen)': round(Crippen.MolLogP(mol), 2),
        'TPSA (Polar Surface Area)': round(rdMolDescriptors.CalcTPSA(mol), 2),
        'HBD (H-Donors)': Lipinski.NumHDonors(mol),
        'HBA (H-Acceptors)': Lipinski.NumHAcceptors(mol),
        'Rotatable Bonds': Lipinski.NumRotatableBonds(mol),
        'Heavy Atom Count': rdMolDescriptors.CalcNumHeavyAtoms(mol),
        'Fraction Csp3': round(rdMolDescriptors.CalcFractionCSP3(mol), 2),
        'Aliphatic Ring Count': rdMolDescriptors.CalcNumAliphaticRings(mol),
        'Aromatic Ring Count': rdMolDescriptors.CalcNumAromaticRings(mol),
        'InChI': inchi,
        'InChIKey': inchikey
    }
    return pd.DataFrame(data.items(), columns=["Descriptor", "Value"])


if uploaded_file is not None:
    st.subheader("🔍 Processing image...")
    image_bytes = uploaded_file.read()
    smiles, error = osra_image_to_smiles(image_bytes)

    if error:
        st.error(error)
    else:
        st.success("✅ SMILES recognized:")
        st.code(smiles, language="none")
        st.download_button("📋 Copy SMILES", smiles, file_name="structure.smiles")

        mol, error_mol = mol_from_smiles(smiles)
        if error_mol:
            st.error(error_mol)
        else:
            st.subheader("🧬 2D Structure")
            st.image(Draw.MolToImage(mol, size=(300, 300)))

            st.subheader("🔢 Chemical Structure")
            st.image(Draw.MolToImage(mol, size=(400, 400), kekulize=True, wedgeBonds=True, legend="Atom indices", includeAtomNumbers=True))

            st.subheader("📊 Molecular Descriptors")
            desc_df = calculate_descriptors(mol)
            st.dataframe(desc_df, use_container_width=True)
            
            if st.button("🔍 Check for suggested descriptive method"):
                try:
                    db_path = "database.csv"  # Arquivo local com as colunas: InChIKey, Descriptive_Method
                    database_df = pd.read_csv(db_path)

                    # Extrair InChIKey dos descritores
                    inchikey_row = desc_df[desc_df["Descriptor"] == "InChIKey"]
                    if not inchikey_row.empty:
                        current_inchikey = inchikey_row["Value"].values[0]

                        match_row = database_df[database_df["InChIKey"] == current_inchikey]
                        if not match_row.empty:
                            method_used = match_row["Descriptive_Method"].values[0]
                            st.success(f"🔎 Suggested descriptive method: **{method_used}** (from database match)")
                        else:
                            st.warning("⚠️ No matching compound found in the database.")
                    else:
                        st.warning("⚠️ Could not extract InChIKey for the current structure.")
                except Exception as e:
                    st.error(f"❌ Could not search database: {e}")


            st.subheader("🌐 Interactive 3D Structure")
            mol3d = generate_3d_model(mol)
            if mol3d:
                viewer = render_3d(mol3d)
                st.components.v1.html(viewer._make_html(), height=400)

                with st.expander("📐 Measure Bond and Dihedral Angles"):
                    st.markdown("You can calculate angles between atoms by entering their indices:")

                    st.subheader("📏 Bond Angle (3 atoms)")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        atom_v1 = st.number_input("Atom 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                    with col2:
                        atom_v2 = st.number_input("Atom 2 (central)", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                    with col3:
                        atom_v3 = st.number_input("Atom 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)

                    if st.button("Calculate Bond Angle"):
                        conf = mol3d.GetConformer()
                        angle_deg = rdMolTransforms.GetAngleDeg(conf, int(atom_v1), int(atom_v2), int(atom_v3))
                        st.success(f"Angle between atoms {atom_v1}-{atom_v2}-{atom_v3}: {round(angle_deg, 2)}°")

                    st.subheader("🌀 Dihedral Angle (4 atoms)")
                    col4, col5, col6, col7 = st.columns(4)
                    with col4:
                        atom_d1 = st.number_input("Atom 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d1")
                    with col5:
                        atom_d2 = st.number_input("Atom 2", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d2")
                    with col6:
                        atom_d3 = st.number_input("Atom 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d3")
                    with col7:
                        atom_d4 = st.number_input("Atom 4", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d4")

                    if st.button("Calculate Dihedral Angle"):
                        conf = mol3d.GetConformer()
                        angle_dihedral = rdMolTransforms.GetDihedralDeg(conf, int(atom_d1), int(atom_d2), int(atom_d3), int(atom_d4))
                        st.success(f"Dihedral between atoms {atom_d1}-{atom_d2}-{atom_d3}-{atom_d4}: {round(angle_dihedral, 2)}°")

            else:
                st.warning("⚠️ Failed to generate 3D structure.")