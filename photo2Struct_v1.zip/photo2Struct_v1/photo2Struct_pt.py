import streamlit as st
import subprocess
import tempfile
import os
from rdkit import Chem
from rdkit.Chem import Draw, Descriptors, rdMolDescriptors, Crippen, Lipinski
from rdkit.Chem import AllChem, rdMolTransforms
import py3Dmol
import pandas as pd

st.set_page_config(layout="wide")
st.title("🧪 photo2Struct – Reconhecimento de Estruturas Químicas")
st.write("Envie uma imagem de uma estrutura química para extrair o **SMILES**, ver a estrutura e obter descritores moleculares.")

uploaded_file = st.file_uploader("📄 Envie uma imagem (PNG ou JPG)", type=["png", "jpg", "jpeg"])

def osra_image_to_smiles(image_bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        tmp.close()
        wsl_path = "/mnt/" + tmp.name[0].lower() + tmp.name[2:].replace('\\', '/').replace('\\\\', '/')
    try:
        result = subprocess.run(["wsl", "osra", wsl_path], capture_output=True, text=True, timeout=15)
        smiles = result.stdout.strip()
        if smiles == "":
            return None, "⚠️ Nenhum SMILES reconhecido."
        return smiles, None
    except Exception as e:
        return None, f"Erro ao executar OSRA: {e}"

def mol_from_smiles(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "SMILES inválido."
    Chem.rdDepictor.Compute2DCoords(mol)
    return mol, None

def generate_3d_model(mol):
    mol3d = Chem.AddHs(mol)
    if AllChem.EmbedMolecule(mol3d) != 0:
        return None
    AllChem.UFFOptimizeMolecule(mol3d)
    return mol3d

def render_3d(mol3d):
    mb = Chem.MolToMolBlock(mol3d)
    viewer = py3Dmol.view(width=400, height=400)
    viewer.addModel(mb, "mol")
    viewer.setStyle({"stick": {}})
    viewer.zoomTo()
    return viewer

def calculate_descriptors(mol):
    data = {
        'Fórmula Molecular': rdMolDescriptors.CalcMolFormula(mol),
        'Massa Exata': round(Descriptors.ExactMolWt(mol), 5),
        'Massa Molecular (g/mol)': round(Descriptors.MolWt(mol), 2),
        'LogP (Crippen)': round(Crippen.MolLogP(mol), 2),
        'TPSA (área polar)': round(rdMolDescriptors.CalcTPSA(mol), 2),
        'HBD (doadores de H)': Lipinski.NumHDonors(mol),
        'HBA (aceptores de H)': Lipinski.NumHAcceptors(mol),
        'Rotatable Bonds': Lipinski.NumRotatableBonds(mol),
        'Heavy Atom Count': rdMolDescriptors.CalcNumHeavyAtoms(mol),
        'Fraction Csp3': round(rdMolDescriptors.CalcFractionCSP3(mol), 2),
        'Aliphatic Ring Count': rdMolDescriptors.CalcNumAliphaticRings(mol),
        'Aromatic Ring Count': rdMolDescriptors.CalcNumAromaticRings(mol),
    }
    return pd.DataFrame(data.items(), columns=["Descritor", "Valor"])

if uploaded_file is not None:
    st.subheader("🔍 Processando imagem...")
    image_bytes = uploaded_file.read()
    smiles, error = osra_image_to_smiles(image_bytes)

    if error:
        st.error(error)
    else:
        st.success("✅ SMILES reconhecido:")
        st.code(smiles, language="none")
        st.download_button("📋 Copiar SMILES", smiles, file_name="structure.smiles")

        mol, error_mol = mol_from_smiles(smiles)
        if error_mol:
            st.error(error_mol)
        else:
            st.subheader("🦮 Estrutura 2D")
            st.image(Draw.MolToImage(mol, size=(300, 300)))

            st.subheader("🔢 Estrutura com Átomos Numerados")
            st.image(Draw.MolToImage(mol, size=(400, 400), kekulize=True, wedgeBonds=True, legend="Atom indices", includeAtomNumbers=True))

            st.subheader("🧮 Descritores Moleculares")
            desc_df = calculate_descriptors(mol)
            st.dataframe(desc_df, use_container_width=True)

            st.subheader("🌐 Estrutura 3D Interativa")
            mol3d = generate_3d_model(mol)
            if mol3d:
                viewer = render_3d(mol3d)
                st.components.v1.html(viewer._make_html(), height=400)

                st.subheader("📐 Calcular Ângulo Vicinal")
                atom_v1 = st.number_input("Índice do átomo 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                atom_v2 = st.number_input("Índice do átomo 2 (central)", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                atom_v3 = st.number_input("Índice do átomo 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                if st.button("Calcular Ângulo"):
                    conf = mol3d.GetConformer()
                    angle_deg = rdMolTransforms.GetAngleDeg(conf, int(atom_v1), int(atom_v2), int(atom_v3))
                    st.success(f"Ângulo entre átomos {atom_v1}-{atom_v2}-{atom_v3}: {round(angle_deg, 2)}°")

                st.subheader("🌀 Calcular Ângulo Diedro")
                atom_d1 = st.number_input("Átomo 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d1")
                atom_d2 = st.number_input("Átomo 2", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d2")
                atom_d3 = st.number_input("Átomo 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d3")
                atom_d4 = st.number_input("Átomo 4", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d4")
                if st.button("Calcular Diedro"):
                    conf = mol3d.GetConformer()
                    angle_dihedral = rdMolTransforms.GetDihedralDeg(conf, int(atom_d1), int(atom_d2), int(atom_d3), int(atom_d4))
                    st.success(f"Diedro entre átomos {atom_d1}-{atom_d2}-{atom_d3}-{atom_d4}: {round(angle_dihedral, 2)}°")
            else:
                st.warning("⚠️ Não foi possível gerar a estrutura 3D.")
