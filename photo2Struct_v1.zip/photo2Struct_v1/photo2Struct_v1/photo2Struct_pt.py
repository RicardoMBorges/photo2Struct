import streamlit as st
import subprocess
import tempfile
import os
from rdkit import Chem
from rdkit.Chem import Draw, Descriptors, rdMolDescriptors, Crippen, Lipinski
from rdkit.Chem import AllChem, rdMolTransforms
import py3Dmol
import pandas as pd

st.set_page_config(layout="wide")
st.title("🧪 photo2Struct – Reconhecimento de Estrutura Química")

# Seção 1: Entrada de SMILES (nova funcionalidade)
smiles_input = st.text_input("📋 Cole uma estrutura em formato SMILES (opcional):", placeholder="ex.: C1=CC=CC=C1")

# Seção 2: Upload de imagem (já existente)
uploaded_file = st.file_uploader("📷 Ou envie uma imagem da estrutura química", type=["png", "jpg", "jpeg"])

mol = None
source = ""

# Processa SMILES
if smiles_input:
    mol = Chem.MolFromSmiles(smiles_input)
    if mol:
        st.success("✅ SMILES interpretado com sucesso!")
        st.image(Draw.MolToImage(mol), caption="Estrutura a partir do SMILES", use_container_width=True)
        source = "SMILES"
    else:
        st.error("❌ SMILES inválido.")

# Processa imagem caso não haja SMILES
elif uploaded_file is not None:
    st.info("🔍 Processando imagem enviada...")
    # Aqui entraria a função real de conversão
    mol = Chem.MolFromSmiles("CCO")  # Simulação temporária
    if mol:
        st.success("✅ Molécula extraída da imagem!")
        st.image(Draw.MolToImage(mol), caption="Estrutura a partir da Imagem", use_container_width=True)
        source = "Imagem"
    else:
        st.error("❌ Não foi possível extrair a estrutura da imagem.")

def osra_image_to_smiles(image_bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        tmp.close()
        wsl_path = "/mnt/" + tmp.name[0].lower() + tmp.name[2:].replace('\\', '/').replace('\\\\', '/')
    try:
        result = subprocess.run(["wsl", "osra", wsl_path], capture_output=True, text=True, timeout=15)
        smiles = result.stdout.strip()
        if smiles == "":
            return None, "⚠️ Nenhum SMILES reconhecido."
        return smiles, None
    except Exception as e:
        return None, f"Erro ao executar o OSRA: {e}"

def mol_from_smiles(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "SMILES inválido."
    Chem.rdDepictor.Compute2DCoords(mol)
    return mol, None

def generate_3d_model(mol):
    mol3d = Chem.AddHs(mol)
    if AllChem.EmbedMolecule(mol3d) != 0:
        return None
    AllChem.UFFOptimizeMolecule(mol3d)
    return mol3d

def render_3d(mol3d):
    mb = Chem.MolToMolBlock(mol3d)
    viewer = py3Dmol.view(width=400, height=400)
    viewer.addModel(mb, "mol")
    viewer.setStyle({"stick": {}})
    viewer.zoomTo()
    return viewer

def calculate_descriptors(mol):
    try:
        inchi = Chem.MolToInchi(mol)
    except:
        inchi = "Indisponível"
    try:
        inchikey = Chem.MolToInchiKey(mol)
    except:
        inchikey = "Indisponível"

    data = {
        'Fórmula Molecular': rdMolDescriptors.CalcMolFormula(mol),
        'Massa Exata': round(Descriptors.ExactMolWt(mol), 5),
        'Peso Molecular (g/mol)': round(Descriptors.MolWt(mol), 2),
        'LogP (Crippen)': round(Crippen.MolLogP(mol), 2),
        'TPSA (Área de Superfície Polar)': round(rdMolDescriptors.CalcTPSA(mol), 2),
        'Doadores de H (HBD)': Lipinski.NumHDonors(mol),
        'Aceitadores de H (HBA)': Lipinski.NumHAcceptors(mol),
        'Ligações Rotacionáveis': Lipinski.NumRotatableBonds(mol),
        'Átomos Pesados': rdMolDescriptors.CalcNumHeavyAtoms(mol),
        'Fração Csp3': round(rdMolDescriptors.CalcFractionCSP3(mol), 2),
        'Anéis Alifáticos': rdMolDescriptors.CalcNumAliphaticRings(mol),
        'Anéis Aromáticos': rdMolDescriptors.CalcNumAromaticRings(mol),
        'InChI': inchi,
        'InChIKey': inchikey
    }
    return pd.DataFrame(data.items(), columns=["Descritor", "Valor"])

# Se houve molécula válida (de SMILES ou imagem), executa o restante do pipeline
if mol:
    st.subheader("🧬 Estrutura 2D")
    st.image(Draw.MolToImage(mol, size=(300, 300)))

    st.subheader("🔢 Estrutura com Índices")
    st.image(Draw.MolToImage(mol, size=(400, 400), kekulize=True, wedgeBonds=True, legend="Índices dos átomos", includeAtomNumbers=True))

    st.subheader("📊 Descritores Moleculares")
    desc_df = calculate_descriptors(mol)
    st.dataframe(desc_df.astype(str), use_container_width=True)

    if st.button("🔍 Sugerir método com base em similaridade química"):
        try:
            db_path = "database.csv"
            database_df = pd.read_csv(db_path)

            if "SMILES" not in database_df.columns or "Descriptive_Method" not in database_df.columns:
                st.warning("⚠️ O banco de dados precisa conter as colunas 'SMILES' e 'Descriptive_Method'.")
            else:
                from rdkit import DataStructs
                from rdkit.Chem import AllChem

                fp_query = AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=2048)

                best_sim = 0
                best_method = None
                best_comment = None

                for idx, row in database_df.iterrows():
                    try:
                        db_mol = Chem.MolFromSmiles(row["SMILES"])
                        if db_mol:
                            fp_db = AllChem.GetMorganFingerprintAsBitVect(db_mol, 2, 2048)
                            sim = DataStructs.TanimotoSimilarity(fp_query, fp_db)
                            if sim > best_sim:
                                best_sim = sim
                                best_method = row["Descriptive_Method"]
                                best_comment = row.get("Additional_comments") if pd.notna(row.get("Additional_comments")) else None
                    except:
                        continue

                if best_sim >= 0.7:
                    st.success(f"🔎 Método sugerido (similaridade {best_sim:.2f}): **{best_method}**")
                    if best_comment:
                        st.info(f"🗒️ Comentário adicional: {best_comment}")
                elif best_sim > 0:
                    st.info(f"O composto mais similar tem similaridade {best_sim:.2f}, mas está abaixo do limite (0.8).")
                else:
                    st.warning("Nenhum composto similar encontrado no banco de dados.")
        except Exception as e:
            st.error(f"❌ Erro na busca por similaridade: {e}")

    st.subheader("🌐 Estrutura 3D Interativa")
    mol3d = generate_3d_model(mol)
    if mol3d:
        viewer = render_3d(mol3d)
        st.components.v1.html(viewer._make_html(), height=400)

        with st.expander("📐 Medir ângulos de ligação e diedros"):
            st.markdown("Você pode calcular ângulos entre átomos inserindo os respectivos índices:")

            st.subheader("📏 Ângulo de Ligação (3 átomos)")
            col1, col2, col3 = st.columns(3)
            with col1:
                atom_v1 = st.number_input("Átomo 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
            with col2:
                atom_v2 = st.number_input("Átomo 2 (central)", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
            with col3:
                atom_v3 = st.number_input("Átomo 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)

            if st.button("Calcular Ângulo de Ligação"):
                conf = mol3d.GetConformer()
                angle_deg = rdMolTransforms.GetAngleDeg(conf, int(atom_v1), int(atom_v2), int(atom_v3))
                st.success(f"Ângulo entre os átomos {atom_v1}-{atom_v2}-{atom_v3}: {round(angle_deg, 2)}°")

            st.subheader("🌀 Ângulo Diedro (4 átomos)")
            col4, col5, col6, col7 = st.columns(4)
            with col4:
                atom_d1 = st.number_input("Átomo 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d1")
            with col5:
                atom_d2 = st.number_input("Átomo 2", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d2")
            with col6:
                atom_d3 = st.number_input("Átomo 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d3")
            with col7:
                atom_d4 = st.number_input("Átomo 4", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d4")

            if st.button("Calcular Ângulo Diedro"):
                conf = mol3d.GetConformer()
                angle_dihedral = rdMolTransforms.GetDihedralDeg(conf, int(atom_d1), int(atom_d2), int(atom_d3), int(atom_d4))
                st.success(f"Ângulo diedro entre os átomos {atom_d1}-{atom_d2}-{atom_d3}-{atom_d4}: {round(angle_dihedral, 2)}°")
    else:
        st.warning("⚠️ Não foi possível gerar a estrutura 3D.")
