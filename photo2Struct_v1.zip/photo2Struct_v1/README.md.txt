# 🧪 photo2Struct

Reconhecimento de estruturas químicas a partir de imagens (PNG/JPG), com visualização 2D e 3D, cálculo de descritores e exportação de SMILES.

## 🚀 Como usar

1. Instale [Miniconda](https://docs.conda.io/en/latest/miniconda.html)
2. Clone este repositório:
   ```bash
   git clone https://github.com/SEU_USUARIO/photo2Struct.git
   cd photo2Struct


3. run_photo2struct.bat


⚠️ Pré-requisitos

* Python 3.9 via Conda

* osra instalado no WSL2 (Linux)

> sudo apt update
> sudo apt install osra

