import streamlit as st
import subprocess
import tempfile
import os
from rdkit import Chem
from rdkit.Chem import Draw, Descriptors, rdMolDescriptors, Crippen, Lipinski
from rdkit.Chem import AllChem, rdMolTransforms
import py3Dmol
import pandas as pd

st.set_page_config(layout="wide")
st.title("🧪 photo2Struct – Chemical Structure Recognition")
st.write("Upload an image of a chemical structure to extract the **SMILES**, view the structure, and get molecular descriptors.")

uploaded_file = st.file_uploader("📄 Upload an image (PNG or JPG)", type=["png", "jpg", "jpeg"])

def osra_image_to_smiles(image_bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        tmp.close()
        wsl_path = "/mnt/" + tmp.name[0].lower() + tmp.name[2:].replace('\\', '/').replace('\\\\', '/')
    try:
        result = subprocess.run(["wsl", "osra", wsl_path], capture_output=True, text=True, timeout=15)
        smiles = result.stdout.strip()
        if smiles == "":
            return None, "⚠️ No SMILES recognized."
        return smiles, None
    except Exception as e:
        return None, f"Error running OSRA: {e}"

def mol_from_smiles(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "Invalid SMILES."
    Chem.rdDepictor.Compute2DCoords(mol)
    return mol, None

def generate_3d_model(mol):
    mol3d = Chem.AddHs(mol)
    if AllChem.EmbedMolecule(mol3d) != 0:
        return None
    AllChem.UFFOptimizeMolecule(mol3d)
    return mol3d

def render_3d(mol3d):
    mb = Chem.MolToMolBlock(mol3d)
    viewer = py3Dmol.view(width=400, height=400)
    viewer.addModel(mb, "mol")
    viewer.setStyle({"stick": {}})
    viewer.zoomTo()
    return viewer

def calculate_descriptors(mol):
    data = {
        'Molecular Formula': rdMolDescriptors.CalcMolFormula(mol),
        'Exact Mass': round(Descriptors.ExactMolWt(mol), 5),
        'Molecular Weight (g/mol)': round(Descriptors.MolWt(mol), 2),
        'LogP (Crippen)': round(Crippen.MolLogP(mol), 2),
        'TPSA (Polar Surface Area)': round(rdMolDescriptors.CalcTPSA(mol), 2),
        'HBD (H-Donors)': Lipinski.NumHDonors(mol),
        'HBA (H-Acceptors)': Lipinski.NumHAcceptors(mol),
        'Rotatable Bonds': Lipinski.NumRotatableBonds(mol),
        'Heavy Atom Count': rdMolDescriptors.CalcNumHeavyAtoms(mol),
        'Fraction Csp3': round(rdMolDescriptors.CalcFractionCSP3(mol), 2),
        'Aliphatic Ring Count': rdMolDescriptors.CalcNumAliphaticRings(mol),
        'Aromatic Ring Count': rdMolDescriptors.CalcNumAromaticRings(mol),
    }
    return pd.DataFrame(data.items(), columns=["Descriptor", "Value"])

if uploaded_file is not None:
    st.subheader("🔍 Processing image...")
    image_bytes = uploaded_file.read()
    smiles, error = osra_image_to_smiles(image_bytes)

    if error:
        st.error(error)
    else:
        st.success("✅ SMILES recognized:")
        st.code(smiles, language="none")
        st.download_button("📋 Copy SMILES", smiles, file_name="structure.smiles")

        mol, error_mol = mol_from_smiles(smiles)
        if error_mol:
            st.error(error_mol)
        else:
            st.subheader("🧬 2D Structure")
            st.image(Draw.MolToImage(mol, size=(300, 300)))

            st.subheader("🔢 Chemical Structure")
            st.image(Draw.MolToImage(mol, size=(400, 400), kekulize=True, wedgeBonds=True, legend="Atom indices", includeAtomNumbers=True))

            st.subheader("📊 Molecular Descriptors")
            desc_df = calculate_descriptors(mol)
            st.dataframe(desc_df, use_container_width=True)

            st.subheader("🌐 Interactive 3D Structure")
            mol3d = generate_3d_model(mol)
            if mol3d:
                viewer = render_3d(mol3d)
                st.components.v1.html(viewer._make_html(), height=400)

                st.subheader("📐 Measure Bond Angle")
                atom_v1 = st.number_input("Atom index 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                atom_v2 = st.number_input("Atom index 2 (central)", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                atom_v3 = st.number_input("Atom index 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1)
                if st.button("Calculate Angle"):
                    conf = mol3d.GetConformer()
                    angle_deg = rdMolTransforms.GetAngleDeg(conf, int(atom_v1), int(atom_v2), int(atom_v3))
                    st.success(f"Angle between atoms {atom_v1}-{atom_v2}-{atom_v3}: {round(angle_deg, 2)}°")

                st.subheader("🌀 Measure Dihedral Angle")
                atom_d1 = st.number_input("Atom 1", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d1")
                atom_d2 = st.number_input("Atom 2", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d2")
                atom_d3 = st.number_input("Atom 3", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d3")
                atom_d4 = st.number_input("Atom 4", min_value=0, max_value=mol.GetNumAtoms() - 1, step=1, key="d4")
                if st.button("Calculate Dihedral"):
                    conf = mol3d.GetConformer()
                    angle_dihedral = rdMolTransforms.GetDihedralDeg(conf, int(atom_d1), int(atom_d2), int(atom_d3), int(atom_d4))
                    st.success(f"Dihedral between atoms {atom_d1}-{atom_d2}-{atom_d3}-{atom_d4}: {round(angle_dihedral, 2)}°")
            else:
                st.warning("⚠️ Failed to generate 3D structure.")
